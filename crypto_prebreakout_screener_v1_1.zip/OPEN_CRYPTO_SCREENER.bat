@echo off
setlocal
title Crypto Pre-Breakout Screener Launcher
cd /d "%~dp0"

echo ============================================================
echo   CRYPTO PRE-BREAKOUT SCREENER
echo ============================================================
echo.
echo Running from:
echo %CD%
echo.

if not exist "app.py" (
  echo ERROR: app.py is missing from this folder.
  echo.
  echo This usually means the BAT file is being run from inside the ZIP.
  echo Right-click the ZIP, choose Extract All, open the extracted folder,
  echo then double-click OPEN_CRYPTO_SCREENER.bat again.
  echo.
  pause
  exit /b 1
)

set "PY_CMD="
where py >nul 2>nul
if %errorlevel%==0 set "PY_CMD=py"
if not defined PY_CMD (
  where python >nul 2>nul
  if %errorlevel%==0 set "PY_CMD=python"
)

if not defined PY_CMD (
  echo ERROR: Python was not found on this PC.
  echo.
  echo Install Python 3.11 or newer from python.org.
  echo IMPORTANT: tick "Add python.exe to PATH" during installation.
  echo Then close this window and run this launcher again.
  echo.
  choice /M "Open the official Python Windows download page now"
  if errorlevel 2 goto :end
  start "" "https://www.python.org/downloads/windows/"
  goto :end
)

echo Python detected:
%PY_CMD% --version
if errorlevel 1 goto :pythonfail
echo.

if not exist ".venv\Scripts\python.exe" (
  echo First run: creating the private Python environment...
  %PY_CMD% -m venv .venv
  if errorlevel 1 goto :venvfail
) else (
  echo Existing private Python environment found.
)

echo.
echo Checking/installing required packages...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 goto :pipfail
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :pipfail

echo.
echo Starting the screener...
start "Crypto Screener Server - KEEP THIS WINDOW OPEN" "%ComSpec%" /k call "%CD%\RUN_SERVER.bat"
timeout /t 5 /nobreak >nul
start "" "http://localhost:8501"

echo.
echo The dashboard should now open in your browser.
echo Keep the separate "Crypto Screener Server" window open while using it.
echo If the browser says it cannot connect, wait a few seconds and refresh.
echo.
pause
exit /b 0

:pythonfail
echo.
echo ERROR: Windows found Python, but it would not run correctly.
echo Reinstall Python 3.11+ and tick "Add python.exe to PATH".
goto :end

:venvfail
echo.
echo ERROR: Could not create the .venv folder.
echo Try extracting the screener to Documents or Desktop rather than running it from the ZIP.
goto :end

:pipfail
echo.
echo ERROR: A required Python package could not be installed.
echo Check that your internet connection is working and that security software is not blocking Python.
echo Then run this launcher again.
goto :end

:end
echo.
pause
endlocal
