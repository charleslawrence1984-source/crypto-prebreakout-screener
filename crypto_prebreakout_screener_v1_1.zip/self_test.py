"""Offline smoke test for the scoring code embedded in app.py.

Run with: python self_test.py
This does not contact an exchange.
"""
from __future__ import annotations

import ast
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd


def load_scoring_namespace():
    src = Path(__file__).with_name("app.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    wanted = {
        "ScreenerConfig", "ema", "rsi", "atr", "obv", "lin_slope",
        "clamp_score", "score_setup",
    }
    nodes = [
        n for n in tree.body
        if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in wanted
    ]
    ns = {"np": np, "pd": pd, "math": math, "dataclass": dataclass, "Dict": dict}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), "<scoring>", "exec"), ns)
    return ns


def synthetic_data():
    np.random.seed(7)
    n = 190
    idx = pd.date_range("2026-01-01", periods=n, freq="4h", tz="UTC")
    base = np.linspace(84, 98.5, n) + np.random.normal(0, 0.35, n)
    high = np.minimum(base + np.abs(np.random.normal(0.5, 0.12, n)), 100.0)
    low = base - np.abs(np.random.normal(0.5, 0.12, n))
    open_ = base + np.random.normal(0, 0.12, n)
    close = base + np.random.normal(0, 0.12, n)
    volume = np.linspace(2000, 800, n) * (1 + np.random.normal(0, 0.05, n))
    coin4 = pd.DataFrame({"timestamp": idx, "open": open_, "high": high, "low": low, "close": close, "volume": volume})

    btc_close = np.linspace(70000, 72500, n) + np.random.normal(0, 100, n)
    btc4 = pd.DataFrame({"timestamp": idx, "open": btc_close, "high": btc_close * 1.002, "low": btc_close * 0.998, "close": btc_close, "volume": 10000})

    d_idx = pd.date_range("2025-10-01", periods=180, freq="1d", tz="UTC")
    d_close = np.linspace(75, 98, 180) + np.random.normal(0, 0.5, 180)
    coind = pd.DataFrame({"timestamp": d_idx, "open": d_close, "high": d_close * 1.01, "low": d_close * 0.99, "close": d_close, "volume": 5000})
    return coin4, coind, btc4


if __name__ == "__main__":
    ns = load_scoring_namespace()
    cfg = ns["ScreenerConfig"]()
    coin4, coind, btc4 = synthetic_data()
    result = ns["score_setup"](coin4, coind, btc4, cfg)
    assert "eligible" in result
    if "score" in result:
        assert 0 <= result["score"] <= 100
        assert result["entry_low"] < result["entry_high"]
        assert result["invalidation"] < result["price"]
    print("PASS — scoring engine smoke test")
    print(result)
