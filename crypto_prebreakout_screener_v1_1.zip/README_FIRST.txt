CRYPTO PRE-BREAKOUT SCREENER - WINDOWS QUICK START

1. IMPORTANT: RIGHT-CLICK THE DOWNLOADED ZIP AND CHOOSE "EXTRACT ALL".
2. Open the extracted folder.
3. Double-click OPEN_CRYPTO_SCREENER.bat.
4. On the first launch it will create a private Python environment and install the required packages.
5. A second black window called "Crypto Screener Server" will stay open.
6. Your browser should open http://localhost:8501 automatically.

If Python is not installed, the launcher will tell you and can open the official Python download page.
Install Python 3.11 or newer and tick "Add python.exe to PATH" during installation.

If the screener fails, DO NOT close the Crypto Screener Server window. Copy the last error shown there into ChatGPT.
