# Pre-Breakout Crypto Screener

A local Streamlit dashboard designed specifically to identify **pre-breakout** crypto setups rather than coins that are already pumping.

## What it does

- Pulls public spot-market data via CCXT; **no exchange API key is required**.
- Supports Binance, Bybit and OKX.
- Ranks the most liquid USDT pairs.
- Uses 4-hour candles for the setup and daily candles for context.
- Rejects coins that are already above the detected resistance level.
- Scores candidates from 0–100 using:
  - higher lows / market structure
  - repeated resistance tests
  - ATR and range compression
  - contracting volume
  - relative strength vs BTC
  - RSI and MACD momentum
  - OBV accumulation proxy
  - daily trend context
  - entry quality / estimated risk-reward
- Displays an entry zone, resistance/breakout level, invalidation level and a rough projected objective.
- Auto-refreshes while the dashboard is open.
- Includes a simple historical event-study backtest for individual candidates.

## Windows — easiest way

1. Install Python 3.11 or newer from python.org if you do not already have Python.
2. Extract this folder somewhere permanent.
3. Double-click `START_WINDOWS.bat`.
4. The first launch creates a virtual environment and installs the required packages.
5. Streamlit opens the dashboard in your web browser.

Later launches are the same: double-click `START_WINDOWS.bat`.

## Manual launch

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

On macOS/Linux, activate with `source .venv/bin/activate` instead.

## Default interpretation

- **90–100:** exceptional / rare pre-breakout alignment
- **80–89:** strong flag
- **70–79:** developing setup
- **Below 70:** usually not worth prioritising

Do not treat those labels as probabilities. A score of 90 does **not** mean a 90% chance of a breakout.

## Important limitations

1. OHLCV candles are secondary exchange data, not tick-by-tick order-flow data.
2. Support/resistance detection is algorithmic and will not interpret every chart like a discretionary trader.
3. The backtest is an event study over the available exchange candle window, not a realistic portfolio simulation with fees, slippage or overlapping-position constraints.
4. Crypto can move through invalidation levels quickly. The screener does not place orders and does not manage position sizing.
5. Exchange APIs can rate-limit or temporarily fail. Reduce the number of coins scanned or lengthen the refresh interval if needed.

## Suggested starting settings

- Exchange: Binance
- Universe: top 50 liquid coins
- Minimum 24h quote volume: $5m
- Flag threshold: 80
- Max distance below resistance: 5%
- Max RSI: 69
- Refresh: 5 minutes

Once enough historical observations have accumulated, tune thresholds using the backtest instead of assuming the defaults are optimal.
