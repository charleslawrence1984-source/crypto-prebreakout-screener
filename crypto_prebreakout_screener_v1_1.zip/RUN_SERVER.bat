@echo off
setlocal
cd /d "%~dp0"
title Crypto Screener Server
set "STREAMLIT_BROWSER_GATHER_USAGE_STATS=false"
set "STREAMLIT_SERVER_HEADLESS=true"
echo Starting dashboard at http://localhost:8501
echo Keep this window open while you use the screener.
echo Press Ctrl+C to stop it.
echo.
".venv\Scripts\python.exe" -m streamlit run "app.py" --server.port 8501 --server.headless true
if errorlevel 1 (
  echo.
  echo ============================================================
  echo THE SCREENER STOPPED WITH AN ERROR.
  echo Copy the error shown above into ChatGPT and I can diagnose it.
  echo ============================================================
  echo.
)
pause
