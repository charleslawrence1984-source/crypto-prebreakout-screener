@echo off
cd /d "%~dp0"
call OPEN_CRYPTO_SCREENER.bat
